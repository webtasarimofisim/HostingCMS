<?php

$lang['paytr_installment_settings']     = 'Taksit Seçenekleri';
$lang['paytr_save_success']             = 'Değişiklikler Başarıyla Kaydedildi!';
$lang['paytr_installment_no_category']  = 'Kategorisi Olmayan Faturalar İçin Max. Taksit Sayısı';
$lang['paytr_installment_all']          = 'Tüm Taksit Seçenekleri';
$lang['paytr_single_installment']       = 'Tek Çekim';
$lang['paytr_installment']              = 'Taksit';