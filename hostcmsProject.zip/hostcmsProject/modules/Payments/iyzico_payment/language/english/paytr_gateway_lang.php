<?php

$lang['paytr_installment_settings']     = 'Installment Settings';
$lang['paytr_save_success']             = 'Changes Saved Successfully!';
$lang['paytr_installment_no_category']  = 'For Uncategorized Invoices Max. Number of Installments';
$lang['paytr_installment_all']          = 'All Installment Options';
$lang['paytr_single_installment']       = 'Single Payment';
$lang['paytr_installment']              = 'Installments';