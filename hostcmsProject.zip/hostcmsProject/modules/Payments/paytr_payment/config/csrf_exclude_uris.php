<?php

defined('BASEPATH') or exit('No direct script access allowed');

return ['paytr_gateway/checkout_module/notify'];
